export class MessageTemplate {

    constructor(message, details){

        this.message = message
        this.details = details

    };
};